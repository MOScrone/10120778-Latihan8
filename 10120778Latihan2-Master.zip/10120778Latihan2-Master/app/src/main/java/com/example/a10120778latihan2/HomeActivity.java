package com.example.a10120778latihan2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.Objects;

public class HomeActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstaceState){
        super.onCreate(savedInstaceState);
        setContentView(R.layout.activity_home);
        Objects.requireNonNull(getSupportActionBar()).hide();
    }
}


//NIM       : 10120778                 -->
//Nama      : SyukurAliNurzaky  -->
//Kelas     : IF- 9                      -->
//Tanggal Pengerjaan : 30-04-2023        -->